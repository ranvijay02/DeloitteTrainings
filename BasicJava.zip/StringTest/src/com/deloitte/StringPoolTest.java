package com.deloitte;

public class StringPoolTest {

	public static void main(String[] args) {
		String s1 = "Hello";
		String s2 = "Hello";
		System.out.println(s1.equals(s2));
		Emp e = new Emp();
	}
}
