package com.deloitte;

public enum OrderField {
	ID,NAME,MOBILE;

}
